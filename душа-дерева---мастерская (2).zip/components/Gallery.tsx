import React from 'react';

const Gallery: React.FC = () => {
  return (
    <section className="py-24 bg-quddix-dark">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          
          <div className="space-y-8">
            <h2 className="text-3xl font-light leading-tight text-white">
              СОВЕРШЕНСТВО <br />
              НЕ СЛУЧАЙНО.
            </h2>
            <div className="w-12 h-[2px] bg-quddix-red"></div>
          </div>

          <div className="space-y-8 text-quddix-muted font-light leading-relaxed">
            <p>
              В Quddix мы верим, что изделие — это продолжение души мастера. 
              Каждая линия, каждый срез создаются с пониманием того, что они останутся на века.
            </p>
            <p>
              Мы убираем всё лишнее. Никакого шума. 
              Только дерево, мастерство и ваши эмоции.
            </p>
            <div className="pt-8">
              <div className="grid grid-cols-2 gap-8 border-t border-quddix-gray/30 pt-8">
                <div>
                   <h4 className="text-white text-lg mb-2">01. Материал</h4>
                   <p className="text-sm">Выдержанное дерево высшего сорта.</p>
                </div>
                <div>
                   <h4 className="text-white text-lg mb-2">02. Душа</h4>
                   <p className="text-sm">Тепло ручной работы в каждом изделии.</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Gallery;