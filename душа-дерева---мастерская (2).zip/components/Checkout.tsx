import React, { useState, useEffect } from 'react';
import { DeliveryDetails, Product, User } from '../types';
import { X, ArrowRight, Truck, CreditCard, Globe, Wallet } from 'lucide-react';

interface CheckoutProps {
  isOpen: boolean;
  onClose: () => void;
  items: Product[];
  total: number;
  currentUser: User | null;
  onSubmit: (details: DeliveryDetails) => void;
}

type PaymentMethod = 'ru_card' | 'int_card' | 'crypto';

const Checkout: React.FC<CheckoutProps> = ({ isOpen, onClose, items, total, currentUser, onSubmit }) => {
  const [step, setStep] = useState<1 | 2>(1); // 1: Delivery, 2: Payment/Confirm
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('ru_card');
  const [details, setDetails] = useState<DeliveryDetails>({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zip: ''
  });

  // Pre-fill if user is logged in
  useEffect(() => {
    if (currentUser && isOpen) {
      setDetails(prev => ({
        ...prev,
        fullName: currentUser.name || '',
        email: currentUser.email || ''
      }));
    }
  }, [currentUser, isOpen]);

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDetails({ ...details, [e.target.name]: e.target.value });
  };

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  const handleFinalSubmit = () => {
    // В реальном приложении здесь вы бы делали редирект на платежный шлюз
    // в зависимости от paymentMethod.
    
    if (paymentMethod === 'ru_card') {
        // Пример: window.location.href = "https://yoomoney.ru/checkout/..."
        console.log("Redirecting to RF Payment Gateway...");
    } else if (paymentMethod === 'int_card') {
        // Пример: window.location.href = "https://stripe.com/checkout/..."
        console.log("Redirecting to International Payment Gateway...");
    }

    // Для демонстрации сразу завершаем заказ
    onSubmit(details);
  };

  return (
    <div className="fixed inset-0 z-[90] bg-quddix-black/98 backdrop-blur-xl flex flex-col animate-fade-in overflow-y-auto">
      {/* Header */}
      <div className="p-6 border-b border-quddix-red/20 flex justify-between items-center bg-quddix-card/20">
        <div className="flex items-center gap-4">
           <div className="w-1 h-6 bg-quddix-red"></div>
           <h2 className="text-xl font-bold tracking-[0.2em] text-white uppercase">Оформление заказа</h2>
        </div>
        <button onClick={onClose} className="text-quddix-muted hover:text-white transition-colors">
          <X size={24} />
        </button>
      </div>

      <div className="flex-grow flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        
        {/* Left Column: Forms */}
        <div className="w-full md:w-2/3 p-8 md:p-12">
            
            {/* Steps Indicator */}
            <div className="flex items-center gap-4 mb-10 text-xs font-bold tracking-widest uppercase">
                <span className={`${step === 1 ? 'text-quddix-red' : 'text-white'}`}>1. Доставка</span>
                <div className="w-8 h-[1px] bg-quddix-gray/30"></div>
                <span className={`${step === 2 ? 'text-quddix-red' : 'text-quddix-muted'}`}>2. Оплата</span>
            </div>

            {step === 1 ? (
                <form onSubmit={handleNext} className="space-y-6 animate-fade-in">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] uppercase text-quddix-muted font-bold tracking-wider">ФИО Получателя</label>
                            <input required name="fullName" value={details.fullName} onChange={handleChange} className="w-full bg-quddix-black border border-quddix-gray/50 p-4 text-white focus:border-quddix-red focus:outline-none transition-colors" placeholder="Иванов Иван Иванович" />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] uppercase text-quddix-muted font-bold tracking-wider">Email</label>
                            <input required name="email" type="email" value={details.email} onChange={handleChange} className="w-full bg-quddix-black border border-quddix-gray/50 p-4 text-white focus:border-quddix-red focus:outline-none transition-colors" placeholder="email@example.com" />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-[10px] uppercase text-quddix-muted font-bold tracking-wider">Телефон</label>
                        <input required name="phone" value={details.phone} onChange={handleChange} className="w-full bg-quddix-black border border-quddix-gray/50 p-4 text-white focus:border-quddix-red focus:outline-none transition-colors" placeholder="+7 (999) 000-00-00" />
                    </div>

                    <div className="space-y-2">
                        <label className="text-[10px] uppercase text-quddix-muted font-bold tracking-wider">Адрес доставки</label>
                        <input required name="address" value={details.address} onChange={handleChange} className="w-full bg-quddix-black border border-quddix-gray/50 p-4 text-white focus:border-quddix-red focus:outline-none transition-colors" placeholder="Улица, дом, квартира" />
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] uppercase text-quddix-muted font-bold tracking-wider">Город</label>
                            <input required name="city" value={details.city} onChange={handleChange} className="w-full bg-quddix-black border border-quddix-gray/50 p-4 text-white focus:border-quddix-red focus:outline-none transition-colors" placeholder="Москва" />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] uppercase text-quddix-muted font-bold tracking-wider">Индекс</label>
                            <input required name="zip" value={details.zip} onChange={handleChange} className="w-full bg-quddix-black border border-quddix-gray/50 p-4 text-white focus:border-quddix-red focus:outline-none transition-colors" placeholder="101000" />
                        </div>
                    </div>

                    <button type="submit" className="mt-8 px-10 py-4 bg-white text-quddix-black font-bold uppercase tracking-widest hover:bg-quddix-red hover:text-white transition-colors flex items-center gap-3">
                        <span>Далее</span>
                        <ArrowRight size={16} />
                    </button>
                </form>
            ) : (
                <div className="animate-fade-in space-y-8">
                    {/* Delivery Summary */}
                    <div className="bg-quddix-card/30 p-6 border border-quddix-red/20">
                        <h3 className="flex items-center gap-3 text-white font-bold uppercase tracking-wider mb-4">
                            <Truck size={20} className="text-quddix-red"/>
                            Данные доставки
                        </h3>
                        <div className="text-sm text-quddix-muted space-y-1">
                            <p><span className="text-white">{details.fullName}</span></p>
                            <p>{details.address}, {details.city}, {details.zip}</p>
                            <p>{details.phone}</p>
                            <p>{details.email}</p>
                        </div>
                        <button onClick={() => setStep(1)} className="text-[10px] text-quddix-red border-b border-quddix-red mt-4 uppercase font-bold hover:text-white hover:border-white transition-colors">Изменить</button>
                    </div>

                    {/* Payment Method Selection */}
                    <div className="space-y-4">
                         <h3 className="flex items-center gap-3 text-white font-bold uppercase tracking-wider">
                            <CreditCard size={20} className="text-quddix-red"/>
                            Способ оплаты
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <button 
                                onClick={() => setPaymentMethod('ru_card')}
                                className={`p-4 border text-left transition-all duration-300 ${paymentMethod === 'ru_card' ? 'border-quddix-red bg-quddix-red/10 text-white' : 'border-quddix-gray/30 text-quddix-muted hover:border-quddix-gray'}`}
                            >
                                <CreditCard className="mb-3 text-quddix-red" size={24} />
                                <div className="font-bold text-sm uppercase mb-1">Карты РФ</div>
                                <div className="text-[10px] opacity-70">MIR, Visa, MasterCard (Russia)</div>
                            </button>

                            <button 
                                onClick={() => setPaymentMethod('int_card')}
                                className={`p-4 border text-left transition-all duration-300 ${paymentMethod === 'int_card' ? 'border-quddix-red bg-quddix-red/10 text-white' : 'border-quddix-gray/30 text-quddix-muted hover:border-quddix-gray'}`}
                            >
                                <Globe className="mb-3 text-quddix-red" size={24} />
                                <div className="font-bold text-sm uppercase mb-1">Весь мир</div>
                                <div className="text-[10px] opacity-70">Visa, MasterCard (International)</div>
                            </button>

                             <button 
                                onClick={() => setPaymentMethod('crypto')}
                                className={`p-4 border text-left transition-all duration-300 ${paymentMethod === 'crypto' ? 'border-quddix-red bg-quddix-red/10 text-white' : 'border-quddix-gray/30 text-quddix-muted hover:border-quddix-gray'}`}
                            >
                                <Wallet className="mb-3 text-quddix-red" size={24} />
                                <div className="font-bold text-sm uppercase mb-1">Crypto</div>
                                <div className="text-[10px] opacity-70">USDT, BTC, ETH</div>
                            </button>
                        </div>
                    </div>

                    <button onClick={handleFinalSubmit} className="w-full py-5 bg-quddix-red text-white font-bold uppercase tracking-[0.2em] hover:bg-red-600 hover:shadow-[0_0_20px_rgba(212,0,0,0.4)] transition-all duration-300">
                        Оплатить ${total.toLocaleString('en-US')}
                    </button>
                </div>
            )}
        </div>

        {/* Right Column: Order Summary */}
        <div className="w-full md:w-1/3 bg-quddix-card/10 border-l border-quddix-gray/10 p-8 md:p-12">
            <h3 className="text-lg font-serif text-white mb-8 border-b border-quddix-gray/30 pb-4">Ваш заказ</h3>
            
            <div className="space-y-4 mb-8 max-h-[400px] overflow-y-auto custom-scrollbar">
                {items.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-start text-sm">
                        <div>
                            <div className="text-white font-medium">{item.name}</div>
                            <div className="text-[10px] text-quddix-muted uppercase tracking-wider">{item.category}</div>
                        </div>
                        <div className="text-quddix-red">{item.displayPrice}</div>
                    </div>
                ))}
            </div>

            <div className="border-t border-quddix-gray/30 pt-6 space-y-2">
                <div className="flex justify-between text-quddix-muted text-sm">
                    <span>Товары</span>
                    <span>${total.toLocaleString('en-US')}</span>
                </div>
                <div className="flex justify-between text-quddix-muted text-sm">
                    <span>Доставка</span>
                    <span>Бесплатно</span>
                </div>
                <div className="flex justify-between text-xl text-white font-bold pt-4">
                    <span>Итого</span>
                    <span>${total.toLocaleString('en-US')}</span>
                </div>
            </div>
        </div>

      </div>
    </div>
  );
};

export default Checkout;