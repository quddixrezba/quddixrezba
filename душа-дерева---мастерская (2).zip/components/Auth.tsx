import React, { useState } from 'react';
import { User } from '../types';
import { X, ArrowRight, AlertCircle, Check } from 'lucide-react';

interface AuthProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: User) => void;
}

// STABLE KEY - DO NOT CHANGE WITHOUT MIGRATION STRATEGY
const STORAGE_KEY_DB = 'quddix_live_store_users';

const Auth: React.FC<AuthProps> = ({ isOpen, onClose, onLogin }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (!email || !password) {
      setError('Заполните все поля');
      return;
    }

    if (isRegistering && !name) {
      setError('Введите ваше имя');
      return;
    }

    // Normalize inputs
    const normalizedEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    // Mock Backend Logic using LocalStorage
    const usersDbStr = localStorage.getItem(STORAGE_KEY_DB);
    const usersDb = usersDbStr ? JSON.parse(usersDbStr) : {};

    if (isRegistering) {
      if (usersDb[normalizedEmail]) {
        setError('Пользователь с таким email уже существует');
        return;
      }
      
      // Save new user
      const newUser: User = { 
        name: name.trim(), 
        email: normalizedEmail, 
        password: cleanPassword,
        cart: [],
        orders: []
      }; 

      // Commit to DB immediately
      usersDb[normalizedEmail] = newUser;
      localStorage.setItem(STORAGE_KEY_DB, JSON.stringify(usersDb));
      
      setSuccessMsg('Аккаунт создан успешно');
      setPassword('');
      
      setTimeout(() => {
        onLogin(newUser);
      }, 1000);
    } else {
      // Login
      const user = usersDb[normalizedEmail];
      if (user) {
        if (user.password === cleanPassword) {
            onLogin(user);
        } else {
            setError('Неверный пароль');
        }
      } else {
        setError('Аккаунт не найден. Пожалуйста, зарегистрируйтесь снова.');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[80] bg-quddix-black/95 backdrop-blur-sm flex items-center justify-center animate-fade-in p-4">
      <div className="bg-quddix-card border border-quddix-red/20 w-full max-w-md relative flex flex-col shadow-2xl">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-quddix-muted hover:text-white transition-colors"
        >
          <X size={24} />
        </button>

        {/* Header */}
        <div className="p-8 border-b border-quddix-red/10 text-center">
          <h2 className="text-2xl font-bold tracking-[0.2em] text-white uppercase mb-2">
            {isRegistering ? 'Регистрация' : 'Вход'}
          </h2>
          <div className="w-12 h-[2px] bg-quddix-red mx-auto"></div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-8 flex flex-col gap-6">
          
          {error && (
            <div className="bg-red-900/20 border border-red-500/50 text-red-200 p-3 text-xs flex items-center gap-2">
              <AlertCircle size={16} />
              {error}
            </div>
          )}

          {successMsg && (
             <div className="bg-green-900/20 border border-green-500/50 text-green-200 p-3 text-xs flex items-center gap-2">
               <Check size={16} />
               {successMsg}
             </div>
          )}

          {isRegistering && (
            <div className="space-y-1">
              <label className="text-xs uppercase tracking-widest text-quddix-muted font-bold">Имя</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-quddix-black border border-quddix-gray text-white p-3 focus:border-quddix-red focus:outline-none transition-colors"
                placeholder="Ваше имя"
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs uppercase tracking-widest text-quddix-muted font-bold">Email</label>
            <input 
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-quddix-black border border-quddix-gray text-white p-3 focus:border-quddix-red focus:outline-none transition-colors"
              placeholder="example@mail.com"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs uppercase tracking-widest text-quddix-muted font-bold">Пароль</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-quddix-black border border-quddix-gray text-white p-3 focus:border-quddix-red focus:outline-none transition-colors"
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit"
            className="mt-4 w-full bg-quddix-red hover:bg-red-700 text-white font-bold uppercase tracking-widest py-4 transition-all duration-300 flex items-center justify-center gap-2 group"
          >
            <span>{isRegistering ? 'Создать аккаунт' : 'Войти'}</span>
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        {/* Footer Toggle */}
        <div className="p-6 border-t border-quddix-red/10 text-center bg-quddix-black/30">
          <p className="text-quddix-muted text-xs">
            {isRegistering ? 'Уже есть аккаунт?' : 'Впервые у нас?'}
            <button 
              onClick={() => {
                setIsRegistering(!isRegistering);
                setError('');
                setSuccessMsg('');
              }}
              className="ml-2 text-white border-b border-quddix-red hover:text-quddix-red transition-colors pb-0.5 uppercase tracking-wider font-bold"
            >
              {isRegistering ? 'Войти' : 'Регистрация'}
            </button>
          </p>
        </div>

      </div>
    </div>
  );
};

export default Auth;