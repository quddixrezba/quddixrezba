import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-quddix-black/90 py-16 border-t border-quddix-red/20 relative z-20">
      <div className="max-w-7xl mx-auto px-6 flex flex-col items-center justify-center gap-6">
        
        {/* Brand */}
        <div className="flex flex-col items-center gap-2">
            <h3 className="text-3xl font-bold tracking-[0.2em] text-white uppercase">QUDDIX</h3>
            <div className="w-8 h-[2px] bg-quddix-red"></div>
            <span className="text-xs font-bold tracking-[0.4em] text-quddix-muted uppercase">Резьба по дереву</span>
        </div>

        {/* Info */}
        <div className="mt-8 text-[10px] text-quddix-muted/60 uppercase tracking-widest text-center leading-loose">
            © 2025 QUDDIX <br/>
            Сделано для ценителей резьбы по дереву
        </div>
      </div>
    </footer>
  );
};

export default Footer;