import React from 'react';
import { Product } from '../types';
import { X, Trash2, ArrowRight } from 'lucide-react';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  items: Product[];
  onRemove: (id: string) => void;
  onCheckout?: () => void;
}

const Cart: React.FC<CartProps> = ({ isOpen, onClose, items, onRemove, onCheckout }) => {
  if (!isOpen) return null;

  const total = items.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="fixed inset-0 z-[70] bg-quddix-black/98 backdrop-blur-xl flex flex-col animate-fade-in text-white">
      {/* Header */}
      <div className="p-8 flex justify-between items-center border-b border-quddix-red/20 bg-quddix-card/30">
        <div className="flex items-center gap-6">
          <div className="w-1 h-8 bg-quddix-red"></div>
          <div>
              <h2 className="text-2xl font-bold tracking-[0.2em] text-white uppercase">Корзина</h2>
              <p className="text-xs text-quddix-muted tracking-widest mt-1">ВАШ ВЫБОР</p>
          </div>
        </div>
        <button 
          onClick={onClose}
          className="text-white hover:text-quddix-red transition-colors p-2"
        >
          <X size={28} />
        </button>
      </div>

      {/* Content */}
      <div className="flex-grow overflow-y-auto">
        <div className="max-w-5xl mx-auto w-full p-8">
          {items.length > 0 ? (
            <div className="space-y-6">
              {items.map((item) => (
                <div key={item.id} className="flex flex-col md:flex-row gap-8 bg-quddix-card/50 p-6 border border-quddix-red/10 items-center group hover:border-quddix-red/40 transition-all duration-300">
                  {/* Image Placeholder */}
                  <div className="w-full md:w-32 h-32 bg-quddix-black border border-quddix-gray/30 flex items-center justify-center shrink-0">
                     <span className="text-[10px] text-quddix-muted uppercase tracking-widest font-bold">Фото</span>
                  </div>

                  <div className="flex-grow text-center md:text-left space-y-2">
                    <div className="text-xs text-quddix-red font-bold uppercase tracking-widest">{item.category}</div>
                    <h3 className="text-xl text-white font-medium tracking-wide">{item.name}</h3>
                  </div>

                  <div className="text-2xl font-light text-white whitespace-nowrap">
                    {item.displayPrice}
                  </div>

                  <button 
                    onClick={() => onRemove(item.id)}
                    className="p-4 text-quddix-muted hover:text-quddix-red transition-colors border border-transparent hover:border-quddix-red/20 rounded-full"
                    title="Удалить"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-[50vh] flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 border-2 border-quddix-gray/20 rounded-full flex items-center justify-center mb-8">
                <div className="w-16 h-1 bg-quddix-gray/20"></div>
              </div>
              <p className="text-white font-bold tracking-[0.2em] text-lg mb-8 uppercase">Ваша корзина пуста</p>
              <button 
                onClick={onClose}
                className="px-10 py-4 bg-white text-quddix-black text-sm font-bold uppercase tracking-[0.2em] hover:bg-quddix-red hover:text-white transition-all duration-300"
              >
                Вернуться к покупкам
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Footer / Checkout */}
      {items.length > 0 && (
        <div className="p-10 border-t border-quddix-red/20 bg-quddix-card/80 backdrop-blur-md">
          <div className="max-w-5xl mx-auto w-full flex flex-col md:flex-row justify-between items-center gap-10">
            <div className="text-center md:text-left">
              <div className="text-quddix-muted text-xs uppercase tracking-widest mb-2 font-bold">Итого к оплате</div>
              <div className="text-4xl text-white font-medium">${total.toLocaleString('en-US')}</div>
            </div>
            
            <button 
              onClick={onCheckout}
              className="px-12 py-5 bg-quddix-red text-white text-sm font-bold uppercase tracking-[0.25em] hover:bg-red-600 hover:shadow-lg transition-all duration-300 flex items-center gap-6 group"
            >
              <span>Оформить заказ</span>
              <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform"/>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;