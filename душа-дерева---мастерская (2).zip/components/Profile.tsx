import React from 'react';
import { User, Order } from '../types';
import { X, LogOut, Package, Clock, ChevronRight } from 'lucide-react';

interface ProfileProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onLogout: () => void;
}

const Profile: React.FC<ProfileProps> = ({ isOpen, onClose, user, onLogout }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[80] bg-quddix-black/95 backdrop-blur-sm flex items-center justify-center animate-fade-in p-4">
      <div className="bg-quddix-card border border-quddix-red/20 w-full max-w-2xl h-[600px] flex flex-col shadow-2xl relative">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-quddix-muted hover:text-white transition-colors"
        >
          <X size={24} />
        </button>

        <div className="flex h-full">
          {/* Sidebar */}
          <div className="w-1/3 bg-quddix-black/50 border-r border-quddix-red/10 p-8 flex flex-col">
             <div className="flex flex-col items-center mb-10 text-center">
                <div className="w-20 h-20 rounded-full bg-quddix-gray/20 border border-quddix-red/30 flex items-center justify-center mb-4 text-2xl font-serif text-white uppercase">
                    {user.name.charAt(0)}
                </div>
                <h2 className="text-xl font-bold text-white tracking-wide">{user.name}</h2>
                <p className="text-xs text-quddix-muted mt-1">{user.email}</p>
             </div>

             <div className="mt-auto">
                <button 
                  onClick={onLogout}
                  className="flex items-center gap-3 text-quddix-muted hover:text-quddix-red transition-colors text-xs font-bold uppercase tracking-widest w-full py-2"
                >
                    <LogOut size={16} />
                    <span>Выйти</span>
                </button>
             </div>
          </div>

          {/* Main Content (Orders) */}
          <div className="w-2/3 p-8 overflow-y-auto">
            <h3 className="text-sm font-bold text-quddix-muted uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
                <Package size={16} />
                История заказов
            </h3>

            {user.orders && user.orders.length > 0 ? (
                <div className="space-y-4">
                    {user.orders.map((order) => (
                        <div key={order.id} className="bg-quddix-black/40 border border-quddix-gray/20 p-4 hover:border-quddix-red/30 transition-colors group">
                            <div className="flex justify-between items-start mb-3">
                                <div>
                                    <div className="text-xs text-quddix-red font-bold uppercase tracking-wider mb-1">Заказ #{order.id.slice(0,6)}</div>
                                    <div className="flex items-center gap-2 text-[10px] text-quddix-muted">
                                        <Clock size={10} />
                                        {new Date(order.date).toLocaleDateString('ru-RU')}
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className="text-white font-medium">${order.total.toLocaleString('en-US')}</div>
                                    <div className="text-[10px] text-green-500 uppercase tracking-widest mt-1">В обработке</div>
                                </div>
                            </div>
                            
                            <div className="border-t border-quddix-gray/10 pt-3 mt-2">
                                <div className="text-[10px] text-quddix-muted mb-2">Товары:</div>
                                <div className="space-y-1">
                                    {order.items.map((item, idx) => (
                                        <div key={idx} className="flex justify-between text-xs text-white">
                                            <span>{item.name}</span>
                                            <span className="text-quddix-muted">{item.displayPrice}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center h-64 text-center opacity-50">
                    <Package size={48} className="text-quddix-gray mb-4" />
                    <p className="text-quddix-muted text-sm">У вас пока нет заказов</p>
                </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;