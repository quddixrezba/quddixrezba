import React, { useState, useRef, useEffect } from 'react';
import { createChatSession } from '../services/geminiService';
import { ChatMessage } from '../types';
import { MessageSquare, X, Send, Loader2 } from 'lucide-react';
import { Chat, GenerateContentResponse } from "@google/genai";

const IdeaGenerator: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatSession = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const initChat = () => {
    if (!chatSession.current) {
      chatSession.current = createChatSession();
      setMessages([{ role: 'model', text: 'Добро пожаловать в Quddix. Я могу рассказать вам о наших работах и философии.' }]);
    }
  };

  const toggleChat = () => {
    if (!isOpen) initChat();
    setIsOpen(!isOpen);
  };

  const handleSend = async () => {
    if (!input.trim() || !chatSession.current || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const response: GenerateContentResponse = await chatSession.current.sendMessage({ message: userMsg });
      const text = response.text || "Извините, я не могу сейчас ответить.";
      setMessages(prev => [...prev, { role: 'model', text: text }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: "Ошибка соединения. Попробуйте позже." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Chat Window */}
      {isOpen && (
        <div className="mb-4 w-[350px] h-[500px] bg-quddix-card border border-quddix-gray/30 shadow-2xl flex flex-col animate-fade-in">
          {/* Header */}
          <div className="p-4 bg-quddix-dark border-b border-quddix-gray/30 flex justify-between items-center">
            <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-quddix-red rounded-full"></div>
                <span className="text-sm font-bold tracking-widest text-white uppercase">Quddix AI</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-quddix-muted hover:text-white">
              <X size={16} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-quddix-black/50">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3 text-sm leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-quddix-gray text-white border border-quddix-gray' 
                    : 'bg-transparent text-quddix-muted border border-quddix-gray/30'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                 <div className="p-3 bg-transparent border border-quddix-gray/30">
                    <Loader2 size={16} className="animate-spin text-quddix-red" />
                 </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 bg-quddix-dark border-t border-quddix-gray/30">
            <div className="relative">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Спросите о работах..."
                className="w-full bg-quddix-black border border-quddix-gray text-white text-sm p-3 pr-10 focus:outline-none focus:border-quddix-red transition-colors placeholder:text-quddix-gray"
              />
              <button 
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="absolute right-3 top-3 text-quddix-muted hover:text-quddix-red disabled:opacity-30 transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button 
        onClick={toggleChat}
        className={`w-14 h-14 bg-quddix-red text-white flex items-center justify-center shadow-lg hover:bg-red-700 transition-all duration-300 ${isOpen ? 'rotate-90 scale-0 opacity-0' : 'rotate-0 scale-100 opacity-100'}`}
      >
        <MessageSquare size={24} />
      </button>
       {/* Close Button replacement when open for better UX, usually handled by window X, but main button can morph */}
       {isOpen && (
           <button 
            onClick={toggleChat}
             className="w-14 h-14 bg-quddix-gray text-white flex items-center justify-center shadow-lg hover:bg-gray-700 transition-all duration-300 absolute bottom-0 right-0"
           >
             <X size={24} />
           </button>
       )}
    </div>
  );
};

export default IdeaGenerator;