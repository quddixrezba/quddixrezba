import React from 'react';
import { Product } from '../types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Скульптура "Тишина"',
    price: 450,
    displayPrice: '$450',
    category: 'Интерьер',
    description: 'Абстрактная форма из мореного дуба.'
  },
  {
    id: '2',
    name: 'Ваза "Корни"',
    price: 280,
    displayPrice: '$280',
    category: 'Декор',
    description: 'Ручная резьба, текстура обожженного дерева.'
  },
  {
    id: '3',
    name: 'Панно "Геометрия"',
    price: 620,
    displayPrice: '$620',
    category: 'Арт',
    description: 'Настенное панно из ясеня и ореха.'
  }
];

interface TechniquesProps {
  onAddToCart?: (product: Product) => void;
}

const Techniques: React.FC<TechniquesProps> = ({ onAddToCart }) => {
  return (
    <div className="w-full h-full overflow-y-auto custom-scrollbar bg-quddix-black">
      <div className="max-w-7xl mx-auto px-6 py-16 md:py-24">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
          <div className="space-y-4">
             <div className="flex items-center gap-3">
                <div className="w-8 h-[1px] bg-quddix-red"></div>
                <h2 className="text-xs font-bold tracking-[0.4em] text-white uppercase">Каталог</h2>
             </div>
             <h3 className="text-4xl md:text-5xl font-serif text-white leading-tight">
               Избранные <br /> 
               <span className="italic text-quddix-red">Работы</span>
             </h3>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-20 pb-20">
          {PRODUCTS.map((product) => (
            <div 
              key={product.id} 
              className="group relative flex flex-col transition-all duration-500 ease-out hover:-translate-y-1 hover:scale-[1.02] hover:shadow-[0_20px_40px_-15px_rgba(212,0,0,0.15)] hover:bg-quddix-card/10 p-6 border border-quddix-gray/30 hover:border-quddix-red/30 rounded-sm"
            >
              
              {/* Minimalist Image Area */}
              <div className="relative aspect-[3/4] w-full bg-quddix-dark border border-quddix-gray/20 mb-8 transition-colors duration-500 group-hover:border-quddix-red/40 overflow-hidden">
                
                {/* Geometric Accents */}
                <div className="absolute top-0 left-0 w-2 h-2 bg-quddix-red opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10"></div>
                <div className="absolute bottom-0 right-0 w-2 h-2 bg-quddix-red opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10"></div>
                
                {/* Image Placeholder */}
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-quddix-black/20 group-hover:bg-quddix-black/0 transition-colors duration-500">
                    <div className="w-[1px] h-16 bg-quddix-gray/20 group-hover:bg-quddix-red/50 transition-colors"></div>
                    <span className="font-serif text-2xl text-quddix-gray/20 group-hover:text-quddix-gray/40 transition-colors italic">
                      Изображение
                    </span>
                </div>
              </div>

              {/* Info */}
              <div className="flex flex-col items-center text-center space-y-3 flex-grow">
                <span className="text-[10px] uppercase tracking-[0.3em] text-quddix-red font-bold">
                     {product.category}
                </span>
                
                <h4 className="text-2xl text-white font-serif tracking-wide group-hover:text-quddix-red transition-colors duration-300">
                     {product.name}
                </h4>
                
                <div className="w-8 h-[1px] bg-quddix-gray/30 group-hover:w-16 group-hover:bg-quddix-red transition-all duration-500 my-2"></div>

                <p className="text-sm text-quddix-muted font-light leading-relaxed max-w-[250px] opacity-70 group-hover:opacity-100 transition-opacity duration-300 mb-4">
                  {product.description}
                </p>
                
                <span className="text-xl font-medium text-white font-mono group-hover:text-quddix-red/80 transition-colors duration-300 mb-4">
                     {product.displayPrice}
                </span>

                {/* VISIBLE BUY BUTTON */}
                <button 
                  onClick={() => onAddToCart && onAddToCart(product)}
                  className="w-full mt-auto py-3 border border-quddix-gray/40 text-quddix-muted text-xs font-bold uppercase tracking-[0.25em] hover:bg-quddix-red hover:text-white hover:border-quddix-red transition-all duration-300"
                >
                  Купить
                </button>
              </div>

            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Techniques;
