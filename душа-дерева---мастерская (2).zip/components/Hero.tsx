import React from 'react';

interface HeroProps {
  onCatalogClick?: () => void;
}

const Hero: React.FC<HeroProps> = ({ onCatalogClick }) => {
  return (
    <section className="relative h-[85vh] flex items-center overflow-hidden">
      
      {/* Background Japanese Calligraphy (Watermark) */}
      {/* "Mokudama" - Spirit of the Wood / Soul of the Tree */}
      <div className="absolute top-1/2 left-1/2 md:left-3/4 transform -translate-x-1/2 -translate-y-1/2 z-0 pointer-events-none select-none mix-blend-overlay">
        <div className="font-serif font-black text-[30vh] md:text-[60vh] text-quddix-red opacity-[0.04] flex flex-col items-center leading-none writing-vertical-rl">
            <span>木</span>
            <span>魂</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 w-full relative z-20">
        <div className="flex flex-row items-center justify-between gap-8 md:gap-16">
          
          <div className="flex flex-row items-start gap-8 md:gap-12">
             {/* Vertical Architectural Line (Minimalist Japanese Element) */}
             <div className="hidden md:flex flex-col items-center gap-4 opacity-0 animate-fade-in py-2">
                <div className="w-[1px] h-20 bg-gradient-to-b from-transparent to-quddix-red"></div>
                <div className="w-1 h-1 rounded-full bg-quddix-red"></div>
                <div className="w-[1px] h-32 bg-gradient-to-b from-quddix-red to-transparent"></div>
             </div>

             <div className="max-w-4xl pt-4 md:pt-8">
                <div className="flex items-center gap-4 mb-6 opacity-0 animate-fade-in delay-100">
                    <div className="w-12 h-[2px] bg-quddix-red shadow-[0_0_10px_rgba(212,0,0,0.5)]"></div>
                    <span className="text-quddix-red font-bold tracking-[0.3em] uppercase text-sm drop-shadow-sm">Ручная работа</span>
                </div>

                <h1 className="text-4xl md:text-6xl lg:text-7xl font-medium tracking-tight text-white mb-10 leading-[1.1] opacity-0 animate-fade-in delay-200 drop-shadow-2xl">
                  Покупайте мои готовые товары, <br className="hidden md:block"/>
                  которые я делал для вас <br className="hidden md:block"/>
                  <span className="text-quddix-red italic font-serif relative">
                    с любовью.
                    {/* Subtle red glow under the key word */}
                    <span className="absolute -bottom-2 left-0 w-full h-[1px] bg-quddix-red/30 blur-sm"></span>
                  </span>
                </h1>

                <p className="text-lg text-quddix-muted max-w-xl mb-12 font-light leading-relaxed opacity-0 animate-fade-in delay-300 border-l border-quddix-gray/30 pl-6">
                    Каждое изделие хранит тепло рук мастера и создано для того, чтобы приносить тишину и гармонию в ваш дом.
                </p>

                <button 
                  onClick={onCatalogClick}
                  className="group relative px-12 py-5 bg-transparent border border-quddix-red/50 text-white text-sm font-bold uppercase tracking-[0.2em] overflow-hidden transition-all duration-500 opacity-0 animate-fade-in delay-500 hover:border-quddix-red hover:shadow-[0_0_30px_rgba(212,0,0,0.2)]"
                >
                  <span className="relative z-10 group-hover:text-white transition-colors duration-300">Перейти в каталог</span>
                  <div className="absolute inset-0 bg-quddix-red transform scale-x-0 origin-left group-hover:scale-x-100 transition-transform duration-500 ease-out -z-0 opacity-90"></div>
                </button>
             </div>
          </div>
        </div>
      </div>
      
      {/* Decorative background element: Red Moon/Sun Motif (Subtle) */}
      <div className="absolute right-[-15%] top-1/2 transform -translate-y-1/2 w-[70vh] h-[70vh] rounded-full border border-quddix-red/5 opacity-40 pointer-events-none z-10"></div>
      <div className="absolute right-[-10%] top-1/2 transform -translate-y-1/2 w-[50vh] h-[50vh] rounded-full bg-gradient-to-br from-quddix-red/5 to-transparent blur-3xl pointer-events-none z-10"></div>
    </section>
  );
};

export default Hero;